
// Observer
public interface Report {
    // Generic data for each report.
    public void update(boolean pass);
    public void printResults();

}
