#!/usr/bin/env bash
javac TreeDemo.java
java TreeDemo
