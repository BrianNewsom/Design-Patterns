#!/usr/bin/env bash
javac Analysis.java
java Analysis xml
echo
java Analysis md
echo
java Analysis html
echo
java Analysis asdf
